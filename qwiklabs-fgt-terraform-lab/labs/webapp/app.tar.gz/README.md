# Demo web server contents

This directory contains files for a simple static web page used in the lab.